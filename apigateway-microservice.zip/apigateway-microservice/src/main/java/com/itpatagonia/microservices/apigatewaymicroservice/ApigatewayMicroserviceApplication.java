package com.itpatagonia.microservices.apigatewaymicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApigatewayMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApigatewayMicroserviceApplication.class, args);
	}

}
