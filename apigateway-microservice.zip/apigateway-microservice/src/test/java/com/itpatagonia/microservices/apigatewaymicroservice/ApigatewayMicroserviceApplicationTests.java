package com.itpatagonia.microservices.apigatewaymicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApigatewayMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
