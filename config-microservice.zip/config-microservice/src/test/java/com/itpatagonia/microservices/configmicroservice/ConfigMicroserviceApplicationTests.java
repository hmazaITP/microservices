package com.itpatagonia.microservices.configmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
